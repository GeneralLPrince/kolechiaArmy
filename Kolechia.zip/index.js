var kolechia = 6403570
var army = 6415623
var cookie = "_|WARNING:-DO-NOT-SHARE-THIS.--Sharing-this-will-allow-someone-to-log-in-as-you-and-to-steal-your-ROBUX-and-items.|_AA616454E3B7F41C71F21D84BD548CE987E200C43AB1DA4C075516169CB4664256597546A0280A7C8040AFF8DBA8059D0D2E9ADB877A8270A581107F15E749A8732005686B02969DFC88AED7607873C54A2140D4DA131EB97CF8D4D01CF65572EBB1DFBB3D2A9D3095832423C5A7ABDFE8FD425EBC76915DA2CA835A5A48B1A41D2C4D3E93187D3BC2BFFFA31383B31E20BE119D2178BE3FFC7742C109AFCD6BC37FAF25A59218EFA394C40952AA67A4CC6B30F0E41B12DF451C38D98806676CFEFD69779CC6325663DDCF46AABA927E600688223B4A6A545BBCEBE13703653F06A26DDF0CA86A9608094ED2F4C1BC24AED17FC917D5AFCB8DC491D490DE2919A1DA1D57E7AE8643EC627DF09040379F12EA4D63C48E56988D6DDEA54D0BF01E151C08353FF16AF2FE34BC020AAC740598C16FFA" // << Put your account cookie inside of the quotes

//INSERT GROUP ID AND COOKIE ABOVE//

const express = require("express");
const rbx = require("noblox.js");
const app = express();

app.use(express.static("public"));
async function startApp() {
  await rbx.cookieLogin(cookie);
  let currentUser = await rbx.getCurrentUser();
  console.log(currentUser.UserName);
}
startApp();

app.get('/', (req, res) => {
    res.sendStatus(200);
  });

app.get("/ranker", async (req, res) => {
  var User = req.param("userid");
  var Rank = req.param("rank");

  rbx.setRank(kolechia, parseInt(User), parseInt(Rank));
  rbx.handleJoinRequest(army, parseInt(User), true)
  res.json("Ranked!");
});

const listener = app.listen(process.env.PORT, () => {
  console.log("Your app is listening on port " + listener.address().port);
});